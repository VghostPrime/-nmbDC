<?php
  session_start()


?>  
<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Pszihologus</title>
        <meta name="description" content="Weiss pszihologus">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">
    </head>
    <body>
      <div id="fejlec">
        <a href="index.php" id="cimerkep" title="WEISSesvagyok.hu - főoldal">
	      <img src="images/logo.png" alt="WEISSesvagyok.hu">
	      </a>

	    <div id="menu">
	      <a href="/meresek/"> MÉRÉSEK </a>  <!-- digit. okt. , TE   -->
	      <a href="/tesztek/"> TESZTEK </a>  <!-- személyiségtesztek -->
	      <a href="/portrek/"> PORTRÉK </a>  <!-- személyiségtesztek -->
	      <a href="/palyaiv/"> PÁLYAÍV </a>  <!-- ... ... ... ...    -->
        <a href="*"> PSZICHOLÓGUS </a>  <!-- ... ... ... ...    -->
          
        <div id="belepes">
            
            
        </div>

	    </div>

  <hr style="clear:both; margin:0;" size="1">
    </div>

    
    <div class='loginFormContainer'>
    <form action='login_ir.php' method=post target='kisablak' >
            <!-- Headings for the form -->
            <div class='headingsContainer'>
                <h3>Jelentkezzen be!</h3>
                
            </div>

            <!-- Main container for all inputs -->
            <div class='mainContainer'>
                <!-- Username -->
                <label for='username'>Felhasználónév/Email</label>
                <input placeholder='' name='email' required>

                <br><br>

                <!-- Password -->
                <label for='pswrd'>Jelszó</label>
                <input type='password' placeholder='' name='pw' required>

                <!-- sub container for the checkbox and forgot password link -->
                
                <div class='subcontainer-1'>
                
                        
                        Emlékezzen rám!
                        <input type='checkbox' name='remember' style='width: 15px; display:right;'>
                    
                    
                
                </div>  


                <!-- Submit button -->
                <button type='submit'>Belépés</button>

                <!-- Sign up link -->
                <p class='register'>Még nincs regisztrálva?  <a href='regisztracio'>Regisztráljon itt!</a></p>
                <p class='forgotpsd'> <a href='#'>Elfelejtettem a jelszavam!</a></p>

            </div>

        </form>
    </div>


<div>
<?php


    $m1 = $_GET['m1'];  

    if( !isset( $_SESSION['uid'] ) )
    {
    
    if( $m1 == "belepes"      )        include( "login.php" ) ;
    if( $m1 == "regisztracio" )        include( "reg.php"   ) ;
    
    }
    else
    {
    print $_SESSION['unick'] . ", Sikeresen beléptél!";
    
    }




    
    
?>
</div>

<iframe name='kisablak' id="kisablak"></iframe>
 


    </body>
</html>